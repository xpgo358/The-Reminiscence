## Initialize new players (give default scores once)
execute as @a[tag=!update1] run scoreboard players set @s prank-level 0
execute as @a[tag=!update1] run scoreboard players set @s recording-status 0
execute as @a[tag=!update1] run scoreboard players set @s streaming-status 0
execute as @a[tag=!update1] run scoreboard players set @s afk-status 0
execute as @a[tag=!update1] run tag @s add update1

# Update teams every tick so prefixes stay in sync
function tr:admin/update_teams

# Triggers
function tr:control/triggers

# Join message
execute as @a if score @s leave matches 1 run function tr:control/join_message